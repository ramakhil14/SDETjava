package SmallestNum;

public class smallestnum {
	public static void main(String[] args) {
		int[] a = {3,2,11,4,6,7};
		int min = a[0];  
        for (int i = 0; i < a.length; i++){  
            //Compare elements of array with max  
           if(a[i] < min)  
               min = a[i];  
        }  
        System.out.println("Minimum value present in given array: " + min);
	}

}
