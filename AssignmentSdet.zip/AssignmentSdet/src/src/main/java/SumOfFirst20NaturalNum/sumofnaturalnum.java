package SumOfFirst20NaturalNum;

public class sumofnaturalnum {

	public static void main(String[] args)   
	{  
	int i, num, sum = 0;  
	//executes until the condition returns true  
	for(i = 1; i <= num; ++i)  
	{  
	//adding the value of i into sum variable  
	sum = sum + i;  
	}  
	//prints the sum   
	System.out.println("Sum of First 20 Natural Numbers is = " + sum);  
	}  
}  
