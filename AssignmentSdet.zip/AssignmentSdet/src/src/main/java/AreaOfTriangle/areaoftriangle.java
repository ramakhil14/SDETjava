package AreaOfTriangle;

public class areaoftriangle {
	   public static void main (String args[])  
	    {          float b=4,h =13,area ;  
	                         area = ( b*h) / 2 ;  
	                         System.out.println("Area of Triangle is: "+area);  
	    }
}
