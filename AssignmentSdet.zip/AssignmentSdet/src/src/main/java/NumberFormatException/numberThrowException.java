package NumberFormatException;

public class numberThrowException {

    public static void main(String[] args) {  
         int a = Integer.parseInt(null); //throws Exception as     //the input string is of illegal format for parsing as it is null.  
    }  
  
} 