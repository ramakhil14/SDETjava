package MaxnMininArray;

public class maxnminvalue {
	public static void main(String[] args) {
        int [] arr = new int [] {11,13,3,7,18,8,9};  
        //Initialize max with first element of array.  
        int max = arr[0];  
        //Loop through the array  
        for (int i = 0; i < arr.length; i++) {  
            //Compare elements of array with max  
           if(arr[i] > max)  
               max = arr[i];  
        }  
        System.out.println("Maxiumum Value present in given array: " + max);  
        int min = arr[0];  
        for (int i = 0; i < arr.length; i++){  
            //Compare elements of array with max  
           if(arr[i] < min)  
               min = arr[i];  
        }  
        System.out.println("Minimum value present in given array: " + min);
	}
}
