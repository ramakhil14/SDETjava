package Oddnum79to187;

public class JavaProgram79to187 {
	public static void main(String args[])   
	{  
	int i=79;  
	System.out.print("List of odd numbers from 79 to 187");  
	for (i=79; i<=187; i++)   
	{  
	//logic to check if the number is odd or not  
	//if i%2 is not equal to zero, the number is odd  
	if (i%2!=0)   
	{  
	System.out.print(i + " ");  
	}  
	}  
	}  

}
